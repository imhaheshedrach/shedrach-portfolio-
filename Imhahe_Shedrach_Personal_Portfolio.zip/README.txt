IMHAHE SHEDRACH (SUPREME) — PERSONAL PORTFOLIO
================================================

Files
-----
- index.html: the complete responsive portfolio website.
- README.txt: these publishing and editing instructions.

BEFORE PUBLISHING
-----------------
Open index.html in a text editor and replace:
1. YOUR-EMAIL@example.com with the email address you want people to use.
2. The X profile link (currently href="#", marked data-placeholder="x") with your full X profile URL.
3. The LinkedIn link (currently href="#", marked data-placeholder="linkedin") with your LinkedIn profile URL.
4. The email social link (currently href="#", marked data-placeholder="email") with mailto:your-email@example.com.
5. Add your graduation year, exact qualification, and any verified details you want to share.

You can edit index.html using a code editor or a plain text editor. Do not share private phone numbers or personal information unless you want them public.

FREE PUBLISHING OPTION: GITHUB PAGES
------------------------------------
1. Sign in or create an account at https://github.com/
2. Create a new repository. A simple name is: shedrach-portfolio
3. Upload index.html to the top/root of that repository (not inside another folder).
4. Open the repository's Settings.
5. Find Pages (usually under the Code and automation section).
6. Under Build and deployment, choose Deploy from a branch.
7. Select the main branch and the / (root) folder, then Save.
8. Wait for GitHub Pages to publish. The site URL will be shown in the Pages section.
9. Open the published URL in Chrome to test it, then add that URL to your X profile's Website field.

ALTERNATIVE: NETLIFY
--------------------
1. Visit https://app.netlify.com/ and sign in.
2. Choose the option to add/deploy a site manually (the wording may vary).
3. Upload the folder containing index.html, or drag the folder into the deploy area if offered.
4. Netlify will provide a public URL. You can change the site name in its settings if available.
5. Test the URL, then add it to your X profile.

NOTES
-----
- This is a static website; it does not need a database or paid hosting.
- A custom domain is optional, not required.
- The website does not yet include a personal photograph. You can add one later if you want.
- Only describe yourself as a graduate, former officer, or business founder where the details are accurate.
